package com.example.btjoystick

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import java.util.concurrent.Executors

@SuppressLint("MissingPermission")
class GamepadHid(
    private val context: Context,
    private val onStatus: (String) -> Unit
) {
    @Volatile private var hid: BluetoothHidDevice? = null
    @Volatile private var host: BluetoothDevice? = null
    private var adapter: BluetoothAdapter? = null
    private val executor = Executors.newSingleThreadExecutor()

    private var buttons = 0
    private var hat = 0
    private var lx = 0
    private var ly = 0
    private var rx = 0
    private var ry = 0

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            onStatus(if (registered) "Ready. Pair and connect a device." else "Registration failed")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    onStatus("Connected to ${device.name ?: "device"}")
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    host = null
                    onStatus("Disconnected")
                }
            }
        }
    }

    fun start(bluetoothAdapter: BluetoothAdapter) {
        adapter = bluetoothAdapter
        bluetoothAdapter.getProfileProxy(context, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                val device = proxy as BluetoothHidDevice
                hid = device
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Phone2Gamepad",
                    "Phone gamepad",
                    "Phone2Gamepad",
                    BluetoothHidDevice.SUBCLASS1_NONE,
                    DESCRIPTOR
                )
                device.registerApp(sdp, null, null, executor, callback)
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
            }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun pairedDevices(): List<BluetoothDevice> =
        adapter?.bondedDevices?.toList() ?: emptyList()

    fun connectTo(device: BluetoothDevice) {
        hid?.connect(device)
    }

    fun stop() {
        val h = hid ?: return
        host?.let { h.disconnect(it) }
        h.unregisterApp()
        adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, h)
        hid = null
    }

    fun setButtons(mask: Int) {
        buttons = mask
        sendReport()
    }

    fun setHat(value: Int) {
        hat = value and 0x0F
        sendReport()
    }

    fun setLeftStick(x: Int, y: Int) {
        lx = clamp(x)
        ly = clamp(y)
        sendReport()
    }

    fun setRightStick(x: Int, y: Int) {
        rx = clamp(x)
        ry = clamp(y)
        sendReport()
    }

    private fun clamp(v: Int) = v.coerceIn(-127, 127)

    // Report (7 bytes): buttons (2) | hat (1) | LX LY RX RY (4)
    private fun sendReport() {
        val device = host ?: return
        val h = hid ?: return
        val report = byteArrayOf(
            (buttons and 0xFF).toByte(),
            ((buttons shr 8) and 0xFF).toByte(),
            hat.toByte(),
            lx.toByte(),
            ly.toByte(),
            rx.toByte(),
            ry.toByte()
        )
        executor.execute { h.sendReport(device, 0, report) }
    }

    companion object {
        const val CROSS = 1 shl 0
        const val CIRCLE = 1 shl 1
        const val TRIANGLE = 1 shl 2
        const val SQUARE = 1 shl 3
        const val L1 = 1 shl 4
        const val R1 = 1 shl 5
        const val L2 = 1 shl 6
        const val R2 = 1 shl 7
        const val L3 = 1 shl 8
        const val R3 = 1 shl 9
        const val OPTIONS = 1 shl 10
        const val CREATE = 1 shl 11
        const val TOUCHPAD = 1 shl 12
        const val PS = 1 shl 13
        const val MUTE = 1 shl 14
        const val INVENTORY = 1 shl 15

        // Hat: 0 = neutral, 1 = N, 2 = NE, 3 = E, 4 = SE, 5 = S, 6 = SW, 7 = W, 8 = NW
        fun hatValue(up: Boolean, right: Boolean, down: Boolean, left: Boolean): Int = when {
            up && right -> 2
            right && down -> 4
            down && left -> 6
            left && up -> 8
            up -> 1
            right -> 3
            down -> 5
            left -> 7
            else -> 0
        }

        private val DESCRIPTOR = intArrayOf(
            0x05, 0x01, 0x09, 0x05, 0xA1, 0x01,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x10,
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x10, 0x81, 0x02,
            0x05, 0x01, 0x09, 0x39, 0x15, 0x01, 0x25, 0x08,
            0x35, 0x00, 0x46, 0x3B, 0x01, 0x65, 0x14,
            0x75, 0x04, 0x95, 0x01, 0x81, 0x42,
            0x75, 0x04, 0x95, 0x01, 0x81, 0x03,
            0x09, 0x30, 0x09, 0x31, 0x09, 0x33, 0x09, 0x34,
            0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x04, 0x81, 0x02,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }
}
