package com.example.btjoystick

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

class JoystickView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onMove: ((Int, Int) -> Unit)? = null
    var deadZone = 0.04f

    private var knobX = 0f
    private var knobY = 0f

    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#191B1F") }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#30343A")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val knobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#22252A") }
    private val knobRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#B6F36A")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.95f
        canvas.drawCircle(cx, cy, r, basePaint)
        canvas.drawCircle(cx, cy, r, ringPaint)

        val travel = r * 0.6f
        val kx = cx + knobX * travel
        val ky = cy + knobY * travel
        val knobR = r * 0.3f
        canvas.drawCircle(kx, ky, knobR, knobPaint)
        canvas.drawCircle(kx, ky, knobR, knobRingPaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val travel = min(width, height) / 2f * 0.95f * 0.6f
                if (travel <= 0f) return true

                var dx = (e.x - width / 2f) / travel
                var dy = (e.y - height / 2f) / travel
                val len = sqrt(dx * dx + dy * dy)
                if (len > 1f) {
                    dx /= len
                    dy /= len
                }

                knobX = applyDeadZone(dx)
                knobY = applyDeadZone(dy)
                onMove?.invoke((knobX * 127).roundToInt(), (knobY * 127).roundToInt())
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                knobX = 0f
                knobY = 0f
                onMove?.invoke(0, 0)
                invalidate()
            }
        }
        return true
    }

    private fun applyDeadZone(v: Float): Float {
        val a = abs(v)
        if (a < deadZone) return 0f
        val scaled = (a - deadZone) / (1f - deadZone)
        return if (v < 0f) -scaled else scaled
    }
}
