package com.example.btjoystick

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var hid: GamepadHid
    private lateinit var adapter: BluetoothAdapter
    private lateinit var status: TextView

    private var buttonState = 0
    private var dpadBits = 0  // bit 0 = up, 1 = right, 2 = down, 3 = left

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        hid = GamepadHid(this) { msg -> runOnUiThread { status.text = msg } }

        bindControls()
        requestBluetoothPermissions()
    }

    override fun onDestroy() {
        hid.stop()
        super.onDestroy()
    }

    private fun bindControls() {
        val joyLeft = findViewById<JoystickView>(R.id.joy_left)
        val joyRight = findViewById<JoystickView>(R.id.joy_right)
        joyLeft.onMove = { x, y -> hid.setLeftStick(x, y) }
        joyRight.onMove = { x, y -> hid.setRightStick(x, y) }

        bindHold(findViewById(R.id.btn_l1), GamepadHid.L1)
        bindHold(findViewById(R.id.btn_l2), GamepadHid.L2)
        bindHold(findViewById(R.id.btn_r1), GamepadHid.R1)
        bindHold(findViewById(R.id.btn_r2), GamepadHid.R2)

        bindTap(findViewById(R.id.btn_triangle), GamepadHid.TRIANGLE)
        bindHold(findViewById(R.id.btn_circle), GamepadHid.CIRCLE)
        bindTap(findViewById(R.id.btn_cross), GamepadHid.CROSS)
        bindTap(findViewById(R.id.btn_square), GamepadHid.SQUARE)

        bindToggle(findViewById(R.id.btn_l3), GamepadHid.L3)
        bindToggle(findViewById(R.id.btn_r3), GamepadHid.R3)

        bindTap(findViewById(R.id.btn_create), GamepadHid.CREATE)
        bindTap(findViewById(R.id.btn_options), GamepadHid.OPTIONS)
        bindTap(findViewById(R.id.btn_ps_home), GamepadHid.PS)
        bindTap(findViewById(R.id.btn_mute), GamepadHid.MUTE)
        bindTouchpad(findViewById(R.id.touchpad))

        bindDpad(findViewById(R.id.dpad_up), 0)
        bindDpad(findViewById(R.id.dpad_right), 1)
        bindDpad(findViewById(R.id.dpad_down), 2)
        bindDpad(findViewById(R.id.dpad_left), 3)

        findViewById<View>(R.id.btn_connect).setOnClickListener { showDevicePicker() }
    }

    private fun press(mask: Int) {
        buttonState = buttonState or mask
        hid.setButtons(buttonState)
    }

    private fun release(mask: Int) {
        buttonState = buttonState and mask.inv()
        hid.setButtons(buttonState)
    }

    private fun bindHold(view: View, mask: Int) {
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> press(mask)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> release(mask)
            }
            true
        }
    }

    private fun bindTap(view: View, mask: Int) {
        view.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) tap(v, mask)
            true
        }
    }

    private fun tap(view: View, mask: Int) {
        press(mask)
        view.postDelayed({ release(mask) }, 60)
    }

    private fun bindToggle(view: View, mask: Int) {
        view.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                buttonState = buttonState xor mask
                hid.setButtons(buttonState)
            }
            true
        }
    }

    private fun bindTouchpad(view: View) {
        view.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                val mask = if (e.x < v.width / 2f) GamepadHid.TOUCHPAD else GamepadHid.INVENTORY
                tap(v, mask)
            }
            true
        }
    }

    private fun bindDpad(view: View, bit: Int) {
        val mask = 1 shl bit
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> dpadBits = dpadBits or mask
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dpadBits = dpadBits and mask.inv()
            }
            hid.setHat(
                GamepadHid.hatValue(
                    up = dpadBits and 1 != 0,
                    right = dpadBits and 2 != 0,
                    down = dpadBits and 4 != 0,
                    left = dpadBits and 8 != 0
                )
            )
            true
        }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val needed = arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }

            if (needed.isNotEmpty()) {
                requestPermissions(needed.toTypedArray(), 1)
                return
            }
        }
        startHid()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startHid()
        } else {
            status.text = "Bluetooth permission denied"
        }
    }

    private fun startHid() {
        if (!adapter.isEnabled) {
            status.text = "Turn on Bluetooth first"
            return
        }
        hid.start(adapter)
    }

    private fun showDevicePicker() {
        val devices = hid.pairedDevices()
        if (devices.isEmpty()) {
            status.text = "Pair your PC in Bluetooth settings first"
            return
        }
        val names = devices.map { it.name ?: it.address }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Connect to")
            .setItems(names) { _, which -> hid.connectTo(devices[which]) }
            .show()
    }
}
